// module.exports = {
  
// };

const { defineConfig } = require('@vue/cli-service')
module.exports = 
{
  // outputDir: 'dist',
  // publicPath: process.env.NODE_ENV === 'production' ? '/business-demo/' : '/'
}