import Vue from 'vue'

import {
    NavBar,
    Image,
    Col, 
    Row,
    Button,
} from 'vant'

Vue.use(NavBar)
Vue.use(Image)
Vue.use(Col);
Vue.use(Row);
Vue.use(Button);