import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
    {
      path: '/',
      name:"home",
      component: () => import('@/view/home')
    },
    {
      path:'/user',
      name: 'user',
      component: () => import('@/view/user'),
     
    },
    {
      path:'/purchase',
      name: 'purchase',
      component: () => import('@/view/purchase'),
      
    },
    {
      path:'/purchase/hotels',
      name: 'hotels',
      component: () => import('@/view/purchase/hotelslist.vue'),
      
    },
    {
      path:'/purchase/let',
      name: 'let',
      component: () => import('@/view/purchase/letlist.vue'),
      
    },
    {
      path:'/purchase/hotels/detail',
      name: 'hotels-detail',
      component: () => import('@/view/purchase/hoteldetail.vue'),
     
    },
    {
      path:'/AirTickets',
      name: 'air-tickets',
      component: () => import('@/view/AirTickets/index.vue'),
    },
    {
      path:'/purchase/let/detail',
      name: 'let-detail',
      component: () => import('@/view/purchase/letdetail.vue'),
      
    },
]

const router = new VueRouter({
  mode: 'history',
  routes
})

export default router
