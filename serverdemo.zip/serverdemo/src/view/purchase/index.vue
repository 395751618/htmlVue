<template>
    <div>
        <van-nav-bar
        title="直采服务"
        left-text="返回"
        @click-left="onClickRight"
        left-arrow
        >
        </van-nav-bar>
        <van-search v-model="value" placeholder="请输入搜索关键词" />
        <van-swipe :autoplay="3000" indicator-color="white">
            <van-swipe-item v-for="thumb in ads.thumb" :key="thumb">
                <img :src="thumb" >
            </van-swipe-item>
        </van-swipe> 
        <div>
            <nav> 
                <div class="st_home_menu"> 
                    <p>    
                        <router-link to="/purchase/hotels"> 
                            <span><img src="http://www.htgl.cn/uploads/2020/0116/752217df6d7fd3c16323a7ec97aeeada.png"/></span> 
                            <strong>酒店服务</strong> 
                        </router-link>  
                        <router-link to="/purchase/let"> 
                            <span><img src="http://www.htgl.cn/uploads/2020/0116/f66b4d5a825e0acb0bb9bcd25bb8998f.png"/></span> 
                            <strong>租房服务</strong> 
                        </router-link>
                         <a href=""> <span><img src="http://www.htgl.cn/uploads/2020/0116/f66b4d5a825e0acb0bb9bcd25bb8998f.png"/></span> 
                            <strong>采摘服务</strong> 
                        </a>  
                    </p> 
                </div> 
            </nav>
            <van-cell-group>
                <van-cell title="租房推荐" value="更多>"></van-cell>
            </van-cell-group>
            <van-cell :title="标题">
                <template #icon>
                    <van-image :src="require('../../assets/images/let-1.png')" width="16rem" height="12rem"/>
                </template>
                <template #title>
                    <h3 style="margin-left:6px">整租.朗芳园五区 2室1厅</h3>
                </template>
                <template #label>
                    <p style="margin-left:6px">整租.朗芳园五区 2室1厅
                    精选/75㎡/2室1厅1卫/南 北/建融家园
                    精装 集中供暖 随时看房</p>
                    <strong style="color:red;margin-left:6px">￥3600元/月</strong>
                </template>
            </van-cell>
            <van-cell :title="标题">
                <template #icon>
                    <van-image :src="require('../../assets/images/let-2.png')" width="16rem" height="12rem"/>
                </template>
                <template #title>
                    <h3 style="margin-left:6px">整租.朗芳园五区 2室2厅</h3>
                </template>
                <template #label>
                    <p style="margin-left:6px">
                        80.00㎡/2室2厅1卫/南 北/建融家园
                                精装 集中供暖 随时看房
                    </p>
                    <strong style="color:red;margin-left:6px">￥4900元/月</strong>
                </template>
            </van-cell>
            <van-cell-group>
                <van-cell title="酒店推荐" value="更多>"></van-cell>
            </van-cell-group>
            <div style="background-color:#FFFFFF">
                <van-row type="flex" justify="space-around">
                    <van-col span="10">
                        <van-image :src="require('../../assets/images/hotel-img0.png')" />
                        <label style="font-size:14px">北京月亮河璞玥酒店</label>
                        <label style="font-size:10px;color:gray;">近运河文化广场.果园环岛/通州
                            欧式浪漫客房，体验沉浸式花园
                        </label>
                        <label style="color:red;">￥486元起</label>
                    </van-col>
                    <van-col span="10">
                        <van-image :src="require('../../assets/images/hotel-img2.jpg')" />
                        <label style="font-size:14px">北京通州北投希尔顿酒店</label>
                        <label style="font-size:10px;color:gray;">
                        据您直行1.2公里·近通州万达广场
                        有海底小纵队等卡通主题亲子房
                        
                        </label>
                        <label style="color:red;">￥486元起</label>
                    </van-col>
                </van-row>
            </div>
        </div>
    </div>
    
    


    
</template>
<script>
 import {NavBar,Swipe,SwipeItem,Col,Row,Search,Icon,Cell,Image as VanImage} from "vant";
 import router  from '@/router';

 export default{
     components:{
         VanImage,
         [Cell.name]:Cell,
         [Icon.name]:Icon,
         [NavBar.name]: NavBar,
         [Swipe.name]: Swipe,
         [SwipeItem.name]: SwipeItem,
         [Col.name]:Col,
         [Row.name]:Row,
         [Search.name]:Search
     },
     data(){
         return {
             ads: {
                thumb: [
                require('../../assets/images/swipe-1.jpg'),
                require('../../assets/images/swipe-2.jpeg'),
                require('../../assets/images/swipe-3.jpg'),
                ]
            }
         }
     },
     methods:{
         onClickRight(){
             router.push('/')
         }
     }
 };
</script>
<style>
  .my-swipe {
    height: 200px;
  }
</style>