<template>
  <div class="goods">
      <van-nav-bar
        title="北京通州北投希尔顿酒店"
        left-text="返回"
        @click-left="onClickRight"
        left-arrow
        >
        </van-nav-bar>
    <van-swipe class="goods-swipe" :autoplay="3000">
      <van-swipe-item v-for="thumb in goods.thumb" :key="thumb">
        <img :src="thumb" >
      </van-swipe-item>
    </van-swipe>

    <van-cell-group>
      <van-cell>
        <div class="goods-title">{{ goods.title }}</div>
        <div class="goods-descption">据您直行1.2公里·近通州万达广场
        有海底小纵队等卡通主题亲子房
        免费升房 恒温泳池 网红打卡
        1小时前有人预定
        </div>
        <div class="goods-price">￥875.00 起</div>
      </van-cell>
      <van-cell class="goods-express">
        <van-col span="6">销量：229</van-col>
        <van-col span="6">满意度：100%</van-col>
         <van-col span="6">评论：2145条</van-col>
          <van-col span="6">收藏：4307</van-col>
      </van-cell>
    </van-cell-group>

    <van-cell-group class="goods-cell-group">
      <van-cell title="选择房型、入住时间" icon="location-o" is-link @click="sorry" />
    </van-cell-group>

    <van-cell-group class="goods-cell-group">
      <van-cell title="查看商品详情">
      </van-cell>
      <van-cell>
          <div class="goods-descption">
              套餐详情：<br>
              ①单人间住宿一晚（1.5米大床）单人早餐+单人温泉票 售价：788<br>
              ②单人间住宿一晚（1.5米大床）单人早餐+双人温泉票 售价：1088<br>
              ③商务双床间住宿一晚（1.2米单人床*2）双人早餐+双人温泉票 售价：1388<br>
              温泉票包含：温泉浴、洗浴、桑拿、游泳、健身（跑步机、脚踏车、哑铃）、自助午餐（11:00-13:00）、自助晚餐（18：00-21:00）
           </div>
      </van-cell>
    </van-cell-group>

    <van-goods-action>
      <van-goods-action-icon icon="chat-o" @click="sorry">
        客服
      </van-goods-action-icon>
      <!-- <van-goods-action-icon icon="cart-o" @click="onClickCart">
        购物车
      </van-goods-action-icon> -->
      <van-goods-action-button type="warning" @click="sorry">
        电话咨询
      </van-goods-action-button>
      <van-goods-action-button type="danger" @click="sorry">
        立即预定
      </van-goods-action-button>
    </van-goods-action>
  </div>
</template>

<script>
import {
  Tag,
  Col,
  Icon,
  Cell,
  CellGroup,
  Swipe,
  Toast,
  SwipeItem,
  GoodsAction,
  GoodsActionIcon,
  GoodsActionButton,
  NavBar
} from 'vant';
 import router  from '@/router';

export default {
  components: {
      [NavBar.name]:NavBar,
    [Tag.name]: Tag,
    [Col.name]: Col,
    [Icon.name]: Icon,
    [Cell.name]: Cell,
    [CellGroup.name]: CellGroup,
    [Swipe.name]: Swipe,
    [SwipeItem.name]: SwipeItem,
    [GoodsAction.name]: GoodsAction,
    [GoodsActionIcon.name]: GoodsActionIcon,
    [GoodsActionButton.name]: GoodsActionButton
  },

  data() {
    return {
      goods: {
        title: '北京通州北投希尔顿酒店',
        price:875.00,
        express: '免运费',
        remain: 19,
        thumb: [
          require('../../assets/images/hotel-d-img1.jpg'),
          require('../../assets/images/hotel-d-img2.jpg'),
          require('../../assets/images/hotel-d-img3.jpg'),
          require('../../assets/images/hotel-d-img4.jpg'),
          require('../../assets/images/hotel-d-img5.jpg'),
        ]
      }
    };
  },

  methods: {
    formatPrice() {
      return '¥' + (this.goods.price / 100).toFixed(2);
    },

    onClickCart() {
      this.$router.push('cart');
    },

    sorry() {
      Toast('暂无后续逻辑~');
    },
    onClickRight(){
        router.push('/purchase/hotels')
    }
  }
};
</script>

<style lang="less">
.goods {
  padding-bottom: 50px;

  &-swipe {
    img {
      width: 100%;
      display: block;
    }
  }

  &-title {
    font-size: 16px;
  }

  &-price {
    color: #f44;
  }

  &-express {
    color: #999;
    font-size: 12px;
    padding: 5px 15px;
  }

  &-cell-group {
    margin: 15px 0;

    .van-cell__value {
      color: #999;
    }
  }

  &-tag {
    margin-left: 5px;
  }
}
</style>
