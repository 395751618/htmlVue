<template>
    <div>
        <van-nav-bar
        title="出租列表"
        left-text="返回"
        @click-left="onClickRight"
        left-arrow>
        </van-nav-bar> 
        <van-search v-model="value" placeholder="请输入搜索关键词" />
        <van-dropdown-menu>
            <van-dropdown-item title="位置">
                <van-tree-select
                    :items="point_items"
                    :main-active-index="pointActiveIndex"
                    :active-id="pointActiveId"
                    @click-nav="pointClickNav"
                    @click-item="pointClickItem"
                    />
            </van-dropdown-item>
            <van-dropdown-item title="整租">
                <van-tree-select
                    :items="type_items"
                    :main-active-index="typeActiveIndex"
                    :active-id="typeActiveId"
                    @click-nav="typeClickNav"
                    @click-item="typeClickItem"
                    />
            </van-dropdown-item>
            <van-dropdown-item title="价格" v-model="value2" :options="option2" />
            <van-dropdown-item title="更多" ref="item">
                <van-tree-select
                    :items="more_items"
                    :main-active-index="moreActiveIndex"
                    :active-id="moreActiveId"
                    @click-nav="moreClickNav"
                    @click-item="moreClickItem"
                    />
            </van-dropdown-item>
        </van-dropdown-menu>
        <van-list
            :finished="finished"
            finished-text="没有更多了"
        >
        <router-link to="/purchase/let/detail">
            <van-cell >
                <template #icon>
                    <van-image :src="require('../../assets/images/let-1.png')" width="16rem" height="12rem"/>
                </template>
                <template #title>
                    <h3 style="margin-left:6px">整租.朗芳园五区 2室1厅</h3>
                </template>
                <template #label>
                    <p style="margin-left:6px">整租.朗芳园五区 2室1厅
                    精选/75㎡/2室1厅1卫/南 北/建融家园
                    精装 集中供暖 随时看房</p>
                    <strong style="color:red;margin-left:6px">￥3600元/月</strong>
                </template>
            </van-cell>
        </router-link>
            <van-cell :title="标题">
                <template #icon>
                    <van-image :src="require('../../assets/images/let-2.png')" width="16rem" height="12rem"/>
                </template>
                <template #title>
                    <h3 style="margin-left:6px">整租.朗芳园五区 2室2厅</h3>
                </template>
                <template #label>
                    <p style="margin-left:6px">
                        80.00㎡/2室2厅1卫/南 北/建融家园
                                精装 集中供暖 随时看房
                    </p>
                    <strong style="color:red;margin-left:6px">￥4900元/月</strong>
                </template>
            </van-cell>
            <van-cell :title="标题">
                <template #icon>
                    <van-image :src="require('../../assets/images/let-3.png')" width="16rem" height="12rem"/>
                </template>
                <template #title>
                    <h3 style="margin-left:6px">整租.朗芳园五区 3室2厅</h3>
                </template>
                <template #label>
                    <p style="margin-left:6px">
                        127㎡/3室2厅2卫/南 北/建融家园
                        精装 集中供暖 随时看房 双卫生间

                    </p>
                    <strong style="color:red;margin-left:6px">￥7900元/月</strong>
                </template>
            </van-cell>
        </van-list>
    </div>
    
    


    
</template>
<script>
 import {
     NavBar,
     Swipe,
     SwipeItem,
     col,
     row,
     Search,
     Icon,
     DropdownMenu,
     DropdownItem,
     List,
     Cell,
     TreeSelect,
     Image as VanImage ,
     Button
     } from "vant";
 import router  from '@/router';

 export default{
     components:{
         [Button.name]:Button,
         VanImage,
         [Cell.name]:Cell,
         [List.name]:List,
         [TreeSelect.name]:TreeSelect,
         [DropdownMenu.name]:DropdownMenu,
         [DropdownItem.name]:DropdownItem,
         [Icon.name]:Icon,
         [NavBar.name]: NavBar,
         [Swipe.name]: Swipe,
         [SwipeItem.name]: SwipeItem,
         [col.name]:col,
         [row.name]:row,
         [Search.name]:Search
     },
     data(){
         return {
             loading:false,
             finished:false,
             ads: {
                thumb: [
                require('../../assets/images/img-2.jpg'),
                require('../../assets/images/img-4.jpg'),
                ]
            },
            value1: 0,
            value2: 0,
            option1: [
                { text: '北京', value: 0 },
                { text: '上海', value: 1 },
                { text: '天津', value: 2 },
                { text: '广州', value: 3 },
            ],
            option2: [
                { text: '不限', value:0 },
                { text: '小于1000元', value:1},
                { text: '1000-2000元', value:2},
                { text: '2000-4000元', value:3},
                { text: '4000-6000元', value:4},
                { text: '6000元以上', value:5},
            ],
            moreActiveId:0,
            moreActiveIndex:0,
            pointActiveId:0,
            pointActiveIndex:0,
            typeActiveId:0,
            typeActiveIndex:0,
            activeId:0,
            activeIndex:0,
            point_items:[
                {text:"区域",children:[
                    {text:"不限",id:0},
                    {text:"东城区",id:1},
                    {text:"西城区",id:2},
                    {text:"朝阳区",id:3},
                    {text:"海淀区",id:4},
                    {text:"丰台区",id:5},
                    {text:"石景山区",id:6},
                    {text:"通州区",id:7},
                    {text:"昌平区",id:8},
                    {text:"大兴区",id:9},
                    {text:"顺义区",id:10},
                    {text:"房山区",id:11},
                ]},
                {text:"地铁",children:[
                    {text:"不限",id:0},
                    {text:"16号线北段",id:1},
                    {text:"地铁10号线",id:2},
                    {text:"地铁13号线",id:3},
                    {text:"地铁14号线东段",id:4},
                    {text:"地铁14号线中段",id:5},
                    {text:"地铁14号线西段",id:6},
                    {text:"地铁15号线",id:7},
                    {text:"地铁1号线",id:8},
                    {text:"地铁2号线",id:9},
                    {text:"地铁5号线",id:10},
                    {text:"地铁6号线",id:11},
                ]},
            ],
            type_items:[
                {text:"整租",children:[
                    {text:"不限",id:0},
                    {text:"1室",id:1},
                    {text:"2室",id:2},
                    {text:"3室+",id:3},
                ]},
                {text:"整租",children:[
                    {text:"不限",id:0},
                    {text:"2室",id:1},
                    {text:"3室",id:2},
                    {text:"4室+",id:3},
                ]}
            ],
            more_items:[
                { text: '面积', children: [
                    {text:"20以下",id:0},
                    {text:'20-40',id:1},
                    {text:'40-60',id:2},
                    {text:'60-80',id:3},
                    {text:'80-100',id:4},
                    {text:'100以上',id:5}
                    ]
                },
                { text: '房源特色', children: [
                    {text:"近地铁",id:0},
                    {text:'南北通',id:1},
                    {text:'精装修',id:2},
                    {text:'配套齐全',id:3},
                    {text:'随时看房',id:4},
                    {text:'独立阳台',id:5},
                    {text:'独卫',id:6},
                    {text:'押一付一',id:7},
                    ]
                },
                { text: '电梯', children: [
                    {text:"无电梯",id:0},
                    {text:'有电梯',id:1}
                    ]
                },
                 { text: '朝向', children: [
                    {text:"南",id:0},
                    {text:'东',id:1},
                    {text:'西',id:2},
                    {text:'北',id:3},
                    {text:'南北',id:4}
                    ]
                },
                { text: '楼层', children: [
                    {text:"低楼层",id:0},
                    {text:'中楼层',id:1},
                    {text:'高楼层',id:2},
                    ]
                },
                { text: '贷款', children: [
                    {text:"安居贷",id:0},
                    ]
                },
                { text: '服务', children: [
                    {text:"可在线签约",id:0}
                    ]
                },
            ]
         }
     },
     methods:{
         onClickRight(){
             router.push('/purchase')
         },
         clickNav(index) {
             this.activeIndex = index
         },
         clickItem(data){
             this.activeId = data['id']
         },
         pointClickNav(index) {
             this.pointActiveIndex = index
         },
         pointClickItem(data){
             this.pointActiveId = data['id']
         },
          typeClickNav(index) {
             this.typeActiveIndex = index
         },
         typeClickItem(data){
             this.typeActiveId = data['id']
         },
         moreClickNav(index) {
             this.moreActiveIndex = index
         },
         moreClickItem(data){
             this.moreActiveId = data['id']
         }
     }
 };
</script>
<style>
  .my-swipe {
    height: 200px;
  }
</style>