<template>
  <div class="goods">
      <van-nav-bar
        title="整租.朗芳园五区 2室1厅"
        left-text="返回"
        @click-left="onClickRight"
        left-arrow
        >
        </van-nav-bar>
    <van-swipe :autoplay="3000">
      <van-swipe-item v-for="thumb in goods.thumb" :key="thumb">
        <img :src="thumb" >
      </van-swipe-item>
    </van-swipe>
    <van-cell-group>
      <van-cell>
        <div class="goods-title">整租.朗芳园五区 2室1厅</div>
        <div class="goods-descption">
        </div>
        <div class="goods-price">￥875.00 起</div>
      </van-cell>
      <van-cell class="goods-express">
          <van-row type="flex" justify="space-between">
              <van-col span="6">
                  <label>季付</label><br>
                  <label style="color:gray;">支付方式</label>
              </van-col>
              <van-col span="6">
                  <label>75㎡</label><br>
                  <label style="color:gray;">面积</label>
              </van-col>
              <van-col span="6">
                  <label>南北</label><br>
                  <label style="color:gray;">朝向</label>
              </van-col>
              <van-col span="6">
                  <label>21楼</label><br>
                  <label style="color:gray;">楼层</label>
              </van-col>
          </van-row>
      </van-cell>
      <van-cell>
          <label>拎包入住 随时看房</label>
          <label>房源简介：有冰箱、洗衣机、空调、热水器、床、暖气、衣柜、天然气
            费用详情：年租价（当租金不足1年时间租金可上浮，详询管家）
            租金:3600	押金:3600	服务费:无

          </label>
      </van-cell>
    </van-cell-group>
    <van-cell-group title="房源管家">
        <van-cell title="王子路" label="运河商务合作房产">
            <template #right-icon>
                <van-icon name="phone-o" size="35"/>
            </template>
        </van-cell>
        <van-cell title="双果" label="运河商务合作房产">
            <template #right-icon>
                <van-icon name="phone-o" size="35"/>
            </template>
        </van-cell>
    </van-cell-group>

    <van-cell-group title="位置及周边">
      <van-cell title="北京市通州区" icon="location-o" @click="sorry" >
          <template #label>
              <van-image :src="require('../../assets/images/map.png')" />
          </template>
      </van-cell>
    </van-cell-group>

    

    <van-goods-action>
      <van-goods-action-icon icon="star-o" @click="sorry">
        收藏
      </van-goods-action-icon>
      <van-goods-action-icon icon="todo-list-o" @click="onClickCart">
        预定
      </van-goods-action-icon>
      <van-goods-action-button type="warning" @click="sorry">
        在线约看
      </van-goods-action-button>
      <van-goods-action-button type="danger" @click="sorry">
        在线咨询
      </van-goods-action-button>
    </van-goods-action>
  </div>
</template>

<script>
import {
  Tag,
  Col,
  Icon,
  Cell,
  CellGroup,
  Swipe,
  Toast,
  SwipeItem,
  GoodsAction,
  GoodsActionIcon,
  GoodsActionButton,
  NavBar,
  Image as VanImage,
} from 'vant';
 import router  from '@/router';

export default {
  components: {
      VanImage,
      [NavBar.name]:NavBar,
    [Tag.name]: Tag,
    [Col.name]: Col,
    [Icon.name]: Icon,
    [Cell.name]: Cell,
    [CellGroup.name]: CellGroup,
    [Swipe.name]: Swipe,
    [SwipeItem.name]: SwipeItem,
    [GoodsAction.name]: GoodsAction,
    [GoodsActionIcon.name]: GoodsActionIcon,
    [GoodsActionButton.name]: GoodsActionButton
  },

  data() {
    return {
      goods: {
        title: '北京通州北投希尔顿酒店',
        price:875.00,
        express: '免运费',
        remain: 19,
        thumb: [
            require('../../assets/images/let-detail-0.png'),
          require('../../assets/images/let-detail-1.png'),
          require('../../assets/images/let-detail-2.png'),
          require('../../assets/images/let-detail-3.png')
        ]
      }
    };
  },

  methods: {
    formatPrice() {
      return '¥' + (this.goods.price / 100).toFixed(2);
    },

    onClickCart() {
      this.$router.push('cart');
    },

    sorry() {
      Toast('暂无后续逻辑~');
    },
    onClickRight(){
        router.push('/purchase/let')
    }
  }
};
</script>

<style lang="less">
.goods {
  padding-bottom: 50px;

  &-swipe {
    img {
      width: 100%;
      display: block;
    }
  }

  &-title {
    font-size: 16px;
  }

  &-price {
    color: #f44;
  }

  &-express {
    color: #999;
    font-size: 12px;
    padding: 5px 15px;
  }

  &-cell-group {
    margin: 15px 0;

    .van-cell__value {
      color: #999;
    }
  }

  &-tag {
    margin-left: 5px;
  }
}
</style>
