<template>
    <div>
        <van-nav-bar
        title="直采酒店列表"
        left-text="返回"
        @click-left="onClickRight"
        left-arrow
        >
        </van-nav-bar> 
         <van-search v-model="value" placeholder="请输入搜索关键词" />
         <van-dropdown-menu>
            <van-dropdown-item title="目的地" v-model="value1" :options="option1" />
            <van-dropdown-item title="排序" v-model="value2" :options="option2" />
            <van-dropdown-item title="筛选" ref="item">
                <van-tree-select
                    :items="items"
                    :main-active-index="activeIndex"
                    :active-id="activeId"
                    @click-nav="clickNav"
                    @click-item="clickItem"
                    />
            </van-dropdown-item>
        </van-dropdown-menu>
        <div>
            <div class="hot_cp_slide">  
                    <div class="st-slider"> 
                        <ul class="am-slides">   
                            <li style="margin-top:15px;"> 
                                <router-link to="/purchase/hotels/detail"> 
                                    <div class="pic">
                                        <img :src="require('../../assets/images/hotel-img2.jpg')" />
                                        </div> 
                                    <div class="rig_txt"> 
                                        <h4 style="color:black;font-size:13px">北京通州北投希尔顿酒店
                                            <p style="color:gray;font-size:10px;">4.8棒 2145点评·4307收藏 近通州万达广场 有海底小纵队等卡通主题亲子房 免费升房 恒温泳池
                                            </p>     
                                        </h4> 
                                         <strong style="color:red;">￥875.00元 起</strong>
                                        
                                    </div> 
                                </router-link> 
                            </li> 
                            <li style="margin-top:15px;"> 
                                <a href="#"> 
                                    <div class="pic">
                                        <img :src="require('../../assets/images/hotel-img0.png')" />
                                        </div> 
                                    <div class="rig_txt"> 
                                        <h4 style="color:black;font-size:13px">北京月亮河璞玥酒店 4星级
                                            <p style="color:gray;font-size:10px;">4.8棒 614人点评 近运河文化广场.果园环岛/通州 欧式浪漫客房，体验沉浸式花园</p>     
                                        </h4> 
                                         <strong style="color:red;">￥486.00元 起</strong>
                                        
                                    </div> 
                                </a> 
                            </li>   
                        </ul> 
                        
                        <div style=" clear:both"></div> 
                    </div> 
             </div>
        </div>
    </div>
    
    


    
</template>
<script>
 import {
     NavBar,
     Swipe,
     SwipeItem,
     col,
     row,
     Search,
     Icon,
     DropdownMenu,
     DropdownItem,
     TreeSelect} from "vant";
 import router  from '@/router';

 export default{
     components:{
         [TreeSelect.name]:TreeSelect,
         [DropdownMenu.name]:DropdownMenu,
         [DropdownItem.name]:DropdownItem,
         [Icon.name]:Icon,
         [NavBar.name]: NavBar,
         [Swipe.name]: Swipe,
         [SwipeItem.name]: SwipeItem,
         [col.name]:col,
         [row.name]:row,
         [Search.name]:Search
     },
     data(){
         return {
             ads: {
                thumb: [
                require('../../assets/images/img-2.jpg'),
                require('../../assets/images/img-4.jpg'),
                ]
            },
            value1: 0,
            value2: 'a',
            option1: [
                { text: '北京', value: 0 },
                { text: '上海', value: 1 },
                { text: '天津', value: 2 },
                { text: '广州', value: 3 },
            ],
            option2: [
                { text: '价格从低到高', value: 'a' },
                { text: '价格从高到底', value: 'b' },
                { text: '销量排序', value: 'c' },
                { text: '产品推荐', value: 'd' },
            ],
            activeId:0,
            activeIndex:0,
            items:[
                { text: '价格', children: [
                    {text:"￥0-￥200",id:0},
                    {text:'￥201-￥500',id:1},
                    {text:'￥501-￥2000',id:2},
                    {text:'￥2001-￥5000',id:3}
                    ]
                },
                { text: '酒店品牌', children: [
                    {text:"希尔顿",id:0},
                    {text:'万豪',id:1},
                    {text:'洲际',id:2},
                    {text:'香格里拉',id:3}
                    ]
                },
                { text: '酒店特征', children: [
                    {text:"全部",id:0},
                    {text:'亲子',id:1},
                    {text:'温泉',id:2},
                    {text:'度假',id:3},
                    {text:'情侣',id:4},
                    {text:'海岛',id:5},
                    {text:'套房',id:6}
                    ]
                },
            ]
         }
     },
     methods:{
         onClickRight(){
             router.push('/purchase')
         },
         clickNav(index) {
             this.activeIndex = index
         },
         clickItem(data){
             this.activeId = data['id']
         }
     }
 };
</script>
<style>
  .my-swipe {
    height: 200px;
  }
</style>