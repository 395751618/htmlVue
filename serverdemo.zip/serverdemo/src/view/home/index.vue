<template>
    <div>
        <van-nav-bar
        title="运河商服"
        @click-right="onClickRight"
        >
            <template #right>
                 <van-icon name="user-circle-o" size="25" color="black"/>
            </template>
        </van-nav-bar> 
        <van-search v-model="value" placeholder="请输入搜索关键词" />
        <van-swipe indicator-color="white">
            <van-swipe-item v-for="thumb in ads.thumb" :key="thumb">
                <img :src="thumb" >
            </van-swipe-item>
        </van-swipe> 
        <div>
            <nav> 
                <div class="st_home_menu"> 
                    <p>
                        <router-link to="/AirTickets">
                            <span><img src="http://www.htgl.cn/uploads/2020/0116/b9a5c9ba1353017deab21414e36c56c4.png"/></span> 
                            <strong>机票</strong> 
                        </router-link> 
                        <a href=""> 
                            <span>
                                <img src="http://www.htgl.cn/uploads/2020/0116/b4b17e8301f82fb5db007c54e6d44c32.png"/></span> 
                            <strong>火车票</strong> 
                        </a>  
                        <a href=""> 
                            <span><img src="http://www.htgl.cn/uploads/2020/0116/a431707118db811520ba7b4f211b740b.png"/></span> 
                            <strong>车辆服务</strong> 
                        </a>  
                        <router-link to="/purchase/hotels"> 
                            <span><img src="http://www.htgl.cn/uploads/2020/0116/752217df6d7fd3c16323a7ec97aeeada.png"/></span> 
                            <strong>酒店服务</strong> 
                        </router-link>  
                        <router-link to="/purchase"> 
                        <span><img src="http://www.htgl.cn/uploads/2020/0116/f66b4d5a825e0acb0bb9bcd25bb8998f.png"/></span> 
                            <strong>直采服务</strong> 
                        </router-link>   
                    </p> 
                </div> 
            </nav>
        </div>
        <van-cell-group>
            <van-cell title="直采服务推荐" />
        </van-cell-group>
        <div style="background-color:#FFFFFF">
            <van-row type="flex" justify="space-around">
                <van-col span="10">
                    <van-image :src="require('../../assets/images/hotel-img0.png')" />
                    <label style="font-size:14px">北京月亮河璞玥酒店</label>
                    <label style="font-size:10px;color:gray;">近运河文化广场.果园环岛/通州
                        欧式浪漫客房，体验沉浸式花园
                    </label>
                    <label style="color:red;">￥486元起</label>
                </van-col>
                <van-col span="10">
                    <van-image :src="require('../../assets/images/hotel-img2.jpg')" />
                    <label style="font-size:14px">北京通州北投希尔顿酒店</label>
                    <label style="font-size:10px;color:gray;">
                    据您直行1.2公里·近通州万达广场
                    有海底小纵队等卡通主题亲子房
                    
                    </label>
                    <label style="color:red;">￥486元起</label>
                </van-col>
            </van-row>
            <van-row type="flex" justify="center">
                <van-col>
                    <van-button type="default" style="">查看更多</van-button>
                </van-col>
                
            </van-row>
            
        </div>
            <!-- <div class="st_hot_list"> 
                    <div class="st_tit"> <h3>直采服务推荐</h3> </div> 
                    <div class="st_list_con"> 
                        <ul class="st_list_ul">   
                            <li> 
                                <a href="http://www.cn/phone/hotels/show_627.html"> 
                                    <p class="pic"><img src="http://www.htgl.cn/uploads/2020/1109/cd549af482098e93f50b309fbe8d0bf0_302x205.jpg" alt="北京好特热温泉酒店"/></p> 
                                    <p class="tit">北京好特热温泉酒店<span class="sell-point">温泉+美食疗养</span></p> 
                                    <p class="num">  <span>
                                        <i class="currency_sy">￥</i><strong>788</strong>起</span>  
                                    </p> 
                                </a> 
                            </li>  
                            <li> 
                                <a href="http://www.cn/phone/hotels/show_631.html"> 
                                    <p class="pic"><img src="http://www.htgl.cn/uploads/2020/1123/6d799413c388a7a7a06495d19ccf4bfb_302x205.jpg" alt="北京朗丽兹西山花园酒店"/></p> 
                                    <p class="tit">北京朗丽兹西山花园酒店<span class="sell-point">泡西山温泉 赏奇老真迹；典藏齐白石真迹；典雅客房 舒适至上</span></p> 
                                    <p class="num">  
                                        <span>
                                        <i class="currency_sy">￥</i><strong>1899</strong>起</span>  
                                    </p> 
                                </a> 
                            </li>  
                            <li> 
                                <a href="http://www.cn/phone/hotels/show_614.html"> 
                                    <p class="pic"><img src="http://www.htgl.cn/uploads/2020/1022/2bf32463c16088d53eeb0fe6d828e6f9_302x205.jpg" alt="北京龙熙维景国际会议中心"/></p> 
                                    <p class="tit">北京龙熙维景国际会议中心<span class="sell-point">双人水世界门票</span></p> 
                                    <p class="num">  
                                        <span>
                                            <i class="currency_sy">￥</i><strong>1088</strong>起</span>  
                                    </p> 
                                </a> 
                            </li>  
                            <li> 
                                <a href="http://www.cn/phone/hotels/show_647.html"> 
                                    <p class="pic"><img src="http://www.htgl.cn/uploads/2020/1022/ea507807508af8bd475e067974b9393d_302x205.jpg" alt="北京龙脉温泉度假村"/></p> 
                                    <p class="tit">北京龙脉温泉度假村<span class="sell-point">小汤山温泉度假区</span></p> 
                                    <p class="num">  <span><i class="currency_sy">￥</i><strong>660</strong>起</span>  
                                    </p> 
                                </a> 
                            </li>  
                        </ul> 
                        <div class="list_more">
                            <van-button type="default">查看更多</van-button>
                        </div> 
                        <div style=" clear:both"></div> 
                    </div> 
                </div>  -->
        
        
    </div> 
</template>

<script>
 import {NavBar,Swipe,SwipeItem,Col,Row,Search,Icon,Button,Cell,Image as VanImage} from "vant";
 import router from '@/router';

 export default{
     components:{
         VanImage,
         [Cell.name]:Cell,
         [Button.name]:Button,
         [Icon.name]:Icon,
         [NavBar.name]: NavBar,
         [Swipe.name]: Swipe,
         [SwipeItem.name]: SwipeItem,
         [Col.name]:Col,
         [Row.name]:Row,
         [Search.name]:Search
     },
     data(){
         return {
             ads: {
                thumb: [
                require('../../assets/images/swipe-1.jpg'),
                require('../../assets/images/swipe-2.jpeg'),
                require('../../assets/images/swipe-3.jpg'),
                ]
            }
         }
     },
     methods:{
         onClickRight(){
             router.push('/user')
         }
     }
 };
</script>
<style>
  .my-swipe {
    height: 300px;
  }
</style>