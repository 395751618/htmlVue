<template>
	<div class="full">
		<div class="top"><van-nav-bar left-arrow title="机票" left-text="返回" @click-left="backClick"></van-nav-bar></div>
		<div class="content">
			<div class="head-bg"><van-image src="https://pages.c-ctrip.com/flight_h5/swift/home/home_bg.png"></van-image></div>
			<div class="search-view">
				<div class="search-title-view">
					<!-- <van-row gutter="20" class="search-title">
                        <van-col span="12">单乘</van-col>
                        <van-col span="12">往返</van-col>
                    </van-row>
                    <div class="seasrch-title-switch">
                        
                    </div> -->
					<div class="search-title11" style="">
						<template v-if="switchIndex === 0">
							<div class="search-title1 search-title1-selected" @click="switchClick(0)">单乘</div>
							<div class="search-title1 search-title1-unselected" @click="switchClick(1)">往返</div>
							<div class="search-title2" style="transform: translateX(0px);"></div>
							<!-- <div class="search-title3 search-title3-left"></div> -->
						</template>
						<template v-else>
							<div class="search-title1 search-title1-unselected" @click="switchClick(0)">单乘</div>
							<div class="search-title1 search-title1-selected" @click="switchClick(1)">往返</div>
							<div class="search-title2" style="transform: translateX(100%);"></div>
							<!-- <div class="search-title3 search-title3-right"></div> -->
						</template>
					</div>
				</div>

				<div class="search-content">
					<van-row class="search-location-view">
						<van-col span="10" @click="fromLocation">
							<transition name="bounce">
								<span class="search-location-left" v-if="switchAddress" style="font-size: 20px; font-weight: bold;">{{ from }}</span>
							</transition>
						</van-col>
						<van-col span="4" class="city-switch-circle-view" @click="switchLocation">
							<template v-if="switchAddress == false">
								<van-image class="city-switch-circle-1" :src="require('../../assets/images/city_switch_circle.png')"></van-image>
							</template>
							<template v-else>
								<van-image class="city-switch-circle-1 city-switch-circle-1-transition" :src="require('../../assets/images/city_switch_circle.png')"></van-image>
							</template>
							<van-image class="city-switch-circle-2" :src="require('../../assets/images/city_switch_icon.png')"></van-image>
						</van-col>
						<van-col span="10" style="text-align: right;" @click="toLocation">
							<span style="font-size: 20px; font-weight: bold;">{{ to }}</span>
						</van-col>
					</van-row>

					<div class="search-date-view" @click="dateClick">
						<span style="font-size: 18px; font-weight: bold;">{{ date }}</span>
						<span>{{ date1 }}</span>
					</div>
					<div class="search-level-view" style="font-size: 15px; font-weight: bold;" @click="levelClick">
						<div>{{ level }}</div>
					</div>
					<div class="search-button-view"><div class="search-button" @click="searchClick">搜索</div></div>
				</div>
			</div>
			<div class="ad-view" @click="adClick"><van-image class="ad" :src="require('../../assets/images/hycqf.png')" :radius="10"></van-image></div>
		</div>
		<div style="height: 10px;"></div>
	</div>
</template>

<script>
export default {
	data() {
		return {
			from: '北京',
			to: '上海',
			date: '03月19号',
			date1: '明天',
			level: '经济舱',
			switchIndex: 0,
			switchAddress: false,
			timer: null,
		};
	},
	mounted() {
		// this.$refs.switchAddressRef.addEventListener('animationend', function() {
		// 	window.console.log('switchAddressRef');
		// })
	},
	methods: {
		backClick() {
			this.$router.back();
		},
		fromLocation() {
			window.console.log('fromLocation');
		},
		switchLocation() {
			window.console.log('switchLocation');
			this.switchAddress = true;
			clearTimeout(this.timer)
			this.timer = setTimeout(() => {
				this.switchAddress = false
			}, 1000)
		},
		animationEnd() {
			window.console.log('animationEnd');
		},
		toLocation() {
			window.console.log('toLocation');
		},
		searchClick() {
			window.console.log('searchClick');
		},
		dateClick() {
			window.console.log('dateClick');
		},
		levelClick() {
			window.console.log('levelClick');
		},
		adClick() {
			window.console.log('adClick');
		},
		switchClick(index) {
			window.console.log('switchClick:', index);
			this.switchIndex = index;
		}
	}
};
</script>

<style>
.full {
}

.top {
	display: flex;
	position: -webkit-sticky;
	position: sticky;
	top: 0px;
	z-index: 99999;
	flex-direction: column;
	margin: 0px;
}

.content {
	display: flex;
	flex-direction: column;
}

.head-bg {
	position: absolute;
}

.search-view {
	z-index: 2;
	background-color: #ffffff;
	border-radius: 10px;
	box-shadow: 1px 1px 5px #c0c0c0;
	margin: 15px 15px 10px 15px;
}

.search-content {
	padding: 10px 15px;
}

.search-title-view {
	position: relative;
	display: flex;
	width: 100%;
}

.search-title {
	text-align: center;
	color: #ffffff;
	font-size: 15px;
	font-weight: bold;
	background-color: #8b97c6;
	justify-content: center;
	align-items: center;
	padding: 12px 0px;
	border-top-left-radius: 10px;
	border-top-right-radius: 10px;
}

.search-title11 {
	display: flex;
	position: relative;
	flex: 1;
	background-color: #8b97c6;
	border-top-left-radius: 10px;
	border-top-right-radius: 10px;
	color: #ffffff;
}

.search-title1 {
	flex: 1;
	position: relative;
	padding: 12px 0px;
	text-align: center;
	z-index: 2;
	font-size: 15px;
	font-weight: bold;
	transition-duration: 2s;
	-webkit-transition-duration: 2s;
	transition-property: color;
	transition-timing-function: ease-out;
	transition-delay: 0s;
}

.search-title1-selected {
	color: #000000;
}

.search-title1-unselected {
	color: #ffffff;
}

.search-title2 {
	position: absolute;
	width: 50%;
	padding: 12px 0px;
	text-align: center;
	top: -5px;
	bottom: 0px;
	border-top-left-radius: 10px;
	border-top-right-radius: 10px;
	background-color: #ffffff;
	transition-duration: 2s;
	-webkit-transition-duration: 2s;
	z-index: 1;
}

.search-title3 {
	position: absolute;
	bottom: 0px;
	width: 10px;
	height: 10px;
	left: 50%;
	transition-duration: 2s;
	-webkit-transition-duration: 2s;
	z-index: 1;
	background-color: transparent;
}

.search-title3-left {
	background-image: radial-gradient(circle 10px at 100% 0%, transparent 50px, white 50%);
}

.search-title3-right {
	background-image: radial-gradient(circle 10px at 100% 0%, transparent 50px, white 50%);
}

.seasrch-title-switch {
	position: absolute;
	width: 50%;
	height: 100%;
	background-color: #007aff;
}

.search-location-view {
	padding: 12px 0px;
	border-bottom: 1px solid #eeeeee;
	margin-bottom: 10px;
}

.search-location-left {
	position: absolute;
}

.city-switch-circle-view {
	display: flex;
	justify-content: center;
	align-items: center;
	position: relative;
}

.city-switch-circle-1 {
	display: block;
	width: 30px;
	height: 30px;
	position: relative;
}

.city-switch-circle-1-transition {
	animation-name: circle-transform;
	animation-duration: 1000ms;
	animation-timing-function: ease-in-out;
	animation-delay: 0;
	animation-iteration-count: 1;
	animation-fill-mode: none;

	/* 
	animation-name: myfirst, rotate-back;
	animation-duration: 1000ms, 10000ms;
	animation-timing-function: linear, linear;
	animation-delay: 0, 1000ms;
	animation-iteration-count: 1, infinite;
	animation-fill-mode: forwards, none;

	-moz-animation-name: myfirst, rotate-back;
	-moz-animation-duration: 1000ms, 10000ms;
	-moz-animation-timing-function: linear, linear;
	-moz-animation-delay: 0, 1000ms;
	-moz-animation-iteration-count: 1, infinite;
	-moz-animation-fill-mode: forwards, none;

	-ms-animation-name: myfirst, rotate-back;
	-ms-animation-duration: 1000ms, 10000ms;
	-ms-animation-timing-function: linear, linear;
	-ms-animation-delay: 0, 1000ms;
	-ms-animation-iteration-count: 1, infinite;
	-ms-animation-fill-mode: forwards, none;

	-o-animation-name: myfirst, rotate-back;
	-o-animation-duration: 1000ms, 10000ms;
	-o-animation-timing-function: linear, linear;
	-o-animation-delay: 0, 1000ms;
	-o-animation-iteration-count: 1, infinite;
	-o-animation-fill-mode: forwards, none;

	-webkit-animation-name: myfirst, rotate-back;
	-webkit-animation-duration: 1000ms, 10000ms;
	-webkit-animation-timing-function: linear, linear;
	-webkit-animation-delay: 0, 1000ms;
	-webkit-animation-iteration-count: 1, infinite;
	-webkit-animation-fill-mode: forwards, none; */
}

@keyframes circle-transform {
	0% {
		-webkit-transform: rotate(0deg);
		-moz-transform: rotate(0deg);
		-o-transform: rotate(0deg);
		-ms-transform: rotate(0deg);
		transform: rotate(0deg);
	}
	50% {
		-webkit-transform: rotate(180deg);
		-moz-transform: rotate(180deg);
		-o-transform: rotate(180deg);
		-ms-transform: rotate(180deg);
		transform: rotate(180deg);
	}
	100% {
		-webkit-transform: rotate(0deg);
		-moz-transform: rotate(0deg);
		-o-transform: rotate(0deg);
		-ms-transform: rotate(0deg);
		transform: rotate(0deg);
	}
}

.bounce-enter-active {
	animation: bounce-in 0.5s;
}
.bounce-leave-active {
	animation: bounce-in 0.5s reverse;
}
@keyframes bounce-in {
	0% {
		transform: scale(0);
	}
	50% {
		transform: scale(1.5);
	}
	100% {
		transform: scale(1);
	}
}

/*myfirst*/
@keyframes myfirst {
	from {
		top: -50px;
	}
	to {
		top: 100px;
	}
}

@-moz-keyframes myfirst {
	from {
		top: -70px;
	}
	to {
		top: 100px;
	}
}

@-webkit-keyframes myfirst {
	from {
		top: 0px;
	}
	to {
		top: 100px;
	}
}

@-ms-keyframes myfirst {
	from {
		top: -300px;
	}
	to {
		top: 100px;
	}
}

@-o-keyframes myfirst {
	from {
		top: -300px;
	}
	to {
		top: 100px;
	}
}

/*rotate-back*/
@keyframes rotate-back {
	from {
		-webkit-transform: rotate(0deg);
		-moz-transform: rotate(0deg);
		-o-transform: rotate(0deg);
		-ms-transform: rotate(0deg);
		transform: rotate(0deg);
	}
	to {
		-webkit-transform: rotate(-360deg);
		-moz-transform: rotate(-360deg);
		-o-transform: rotate(-360deg);
		-ms-transform: rotate(-360deg);
		transform: rotate(-360deg);
	}
}

@-moz-keyframes rotate-back {
	from {
		-moz-transform: rotate(0deg);
		transform: rotate(0deg);
	}
	to {
		-moz-transform: rotate(-360deg);
		transform: rotate(-360deg);
	}
}

@-webkit-keyframes rotate-back {
	from {
		-webkit-transform: rotate(0deg);
		transform: rotate(0deg);
	}
	to {
		-webkit-transform: rotate(-360deg);
		transform: rotate(-360deg);
	}
}

@-ms-keyframes rotate-back {
	from {
		-ms-transform: rotate(0deg);
		transform: rotate(0deg);
	}
	to {
		-ms-transform: rotate(-360deg);
		transform: rotate(-360deg);
	}
}

@-o-keyframes rotate-back {
	from {
		-o-transform: rotate(0deg);
		transform: rotate(0deg);
	}
	to {
		-o-transform: rotate(-360deg);
		transform: rotate(-360deg);
	}
}

.city-switch-circle-2 {
	position: absolute;
	width: 20px;
	height: 20px;
}

.city-switch-circle {
	width: 25px;
	height: 25px;
}

.search-date-view {
	padding: 12px 0px;
	border-bottom: 1px solid #eeeeee;
	margin-bottom: 10px;
}

.search-level-view {
	padding: 12px 0px;
}

.search-button-view {
	padding: 12px 0px;
}

.search-button {
	width: 100%;
	text-align: center;
	color: #ffffff;
	background: linear-gradient(90deg, #f70 0%, #ffa50a 100%);
	padding: 10px 0px;
	border-radius: 10px;
	font-size: 20px;
	font-weight: bold;
}

.ad-view {
	margin: 5px 15px 10px 15px;
}
</style>
