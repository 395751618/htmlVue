<template>
  <div>
    <div class="hello">Hello {{ who }}</div>
    <el-button @click="testMethod">Button</el-button>
  </div>
</template>

<script>
module.exports = {
  data: function () {
    return {
      who: 'world'
    }
  },
  methods: {
    testMethod() {
      console.log('dddddd')
      this.who = 'dddd'
      this.$router.push({ path: 'test1' })
    }
  }
}
</script>
<style>
.hello {
  background-color: #ffe;
}
</style>