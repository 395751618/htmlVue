<template>
  <div>
    fdsalfjaslfkjaksd
  </div>
</template>

<script>
export default {
  name: "test2"
}
</script>

<style scoped>

</style>