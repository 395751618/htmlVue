<template>
  <div class="full">
    <div class="top">
      <el-row type="flex" class="row-bg" justify="space-between">
        <el-col :span="4" class="home-view">
          <el-button class="home" circle icon="el-icon-s-home"></el-button>
        </el-col>
        <el-col :span="10" class="title-view">
          <div class="title">机票</div>
        </el-col>
        <el-col :span="4" class="persion-view">
          <el-button class="person" circle icon="el-icon-s-custom"></el-button>
        </el-col>
      </el-row>
    </div>
    <div class="tab-view">
      <el-tabs :stretch="true" v-model="activeName" type="card" @tab-click="handleClick">
        <el-tab-pane label="单乘" name="first">

        </el-tab-pane>
        <el-tab-pane label="往返" name="second">

        </el-tab-pane>
      </el-tabs>
    </div>

    <div class="section1-view">
      <div style="background-color: #8cc5ff">
        <el-row type="flex" class="section-bg" justify="space-between">
          <el-col :span="12" class="section-left">
            <image style="margin-right: 10px" src="./images/sale_fire.png"></image>
            <span style="font-size: 25px">{{section1.title}}</span>
          </el-col>
          <el-col :span="12" class="section-right">
            {{section1.title}}
          </el-col>
        </el-row>
      </div>
      <div>

      </div>
    </div>

    <div class="section2-view">

    </div>
  </div>
</template>

<script>
module.exports = {
  name: 'AirTickets',
  data: function () {
    return {
      who: 'world',
      activeName: 'first',
      section1: {
        title: '超值低价',
        icon: '',
        data: [
          {
            fromLocation: '北京',
            toLocation: '上海',
            time: '03-03 周六出发',
            price: '250',
            discount: '5折'
          },
          {
            fromLocation: '北京',
            toLocation: '上海',
            time: '03-03 周六出发',
            price: '250',
            discount: '5折'
          },
          {
            fromLocation: '北京',
            toLocation: '上海',
            time: '03-03 周六出发',
            price: '250',
            discount: '5折'
          },
          {
            fromLocation: '北京',
            toLocation: '上海',
            time: '03-03 周六出发',
            price: '250',
            discount: '5折'
          },
          {
            fromLocation: '北京',
            toLocation: '上海',
            time: '03-03 周六出发',
            price: '250',
            discount: '5折'
          },
        ]
      },
      sectoin2: []
    }
  },
  methods: {
    testMethod() {
      console.log('dddddd')
      this.who = 'dddd'
      this.$router.push({path: 'test1'})
    },
    handleClick(tab, event) {
      console.log(tab, event);
    }
  }
}
</script>
<style>
.full {
  width: 100%;
  height: 2000px;
}

.top {
  display: flex;
  position: -webkit-sticky;
  position: sticky;
  top: 0px;
  z-index: 99;
  flex-direction: column;
  margin: 0px;
  background-color: #FFFFFF;
}

.home {
  border-width: 1px;
  border-color: #dfe4ed;
  margin-left: 10px;
}

.title {
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.person {
  border-width: 1px;
  border-color: #dfe4ed;
  margin-right: 10px;
}

.row-bg {
  padding: 10px 0px;
}

.home-view {
  display: flex;
  justify-content: left;
  align-items: center;
}

.title-view {
}

.persion-view {
  text-align: right;
}

.tab-view {
  background-color: #8cc5ff;
  height: 300px;
}

.section-bg {
  padding: 10px 0px;
}

.section-left {
  display: flex;
  justify-content: left;
  align-items: center;
}

.section-right {
  text-align: right;
}

.section1-view {
  display: flex;
  flex-direction: column;
  margin-top: 10px;
}

.section2-view {

}

</style>