<template>
  <div>
    adffasfas
  </div>
</template>

<script>
export default {
  name: "test1"
}
</script>

<style scoped>

</style>