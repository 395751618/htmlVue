var seoConfigDataForMkt = {
	"config": [
		{
			"Name": "baiduboxapp",
			"AllianceID": "66672",
			"SID": "1709144",
			"OUID": "",
			"SourceID": "1825",
			"isUsed": true
		},
		{
			"Name": "mqqbrowser",
			"AllianceID": "66672",
			"SID": "508660",
			"OUID": "",
			"SourceID": "55552319",
			"isUsed": true
		},
		{
			"Name": "sogousearch",
			"AllianceID": "4901",
			"SID": "353698",
			"OUID": "",
			"SourceID": "1828",
			"isUsed": true
		},
		{
			"Name": "easou_client",
			"AllianceID": "5376",
			"SID": "353700",
			"OUID": "",
			"SourceID": "1830",
			"isUsed": true
		},
		{
			"Name": "qhbrowser",
			"AllianceID": "5376",
			"SID": "353699",
			"OUID": "",
			"SourceID": "1829",
			"isUsed": true
		},
		{
			"Name": "roboosearch",
			"AllianceID": "20080",
			"SID": "450748",
			"OUID": "",
			"SourceID": "2131",
			"isUsed": true
		},
		{
			"Name": "sogoumobilebrowser",
			"AllianceID": "66672",
			"SID": "508662",
			"OUID": "",
			"SourceID": "55552321",
			"isUsed": true
		},
		{
			"Name": "bingweb",
			"AllianceID": "4902",
			"SID": "353701",
			"OUID": "",
			"SourceID": "1831",
			"isUsed": true
		},
		{
			"Name": "yabrowser",
			"AllianceID": "5376",
			"SID": "353700",
			"OUID": "",
			"SourceID": "1830",
			"isUsed": true
		},
		{
			"Name": "newsarticle",
			"AllianceID": "1095032",
			"SID": "2238640",
			"OUID": "",
			"SourceID": "",
			"isUsed": true
		},
		//Browser
		{
			"Name": "firefox",
			"AllianceID": "66672",
			"SID": "508668",
			"OUID": "",
			"SourceID": "55552328",
			"isUsed": true
		},
		{
			"Name": "oupeng|opera|opr",
			"AllianceID": "66672",
			"SID": "508666",
			"OUID": "",
			"SourceID": "55552326",
			"isUsed": true
		},
		{
			"Name": "ucbrowser",
			"AllianceID": "66672",
			"SID": "508659",
			"OUID": "",
			"SourceID": "55552318",
			"isUsed": true
		},
		{
			"Name": "hao123",
			"AllianceID": "66672",
			"SID": "508665",
			"OUID": "",
			"SourceID": "55552325",
			"isUsed": true
		},
		{
			"Name": "360|qihoo|qihu",
			"AllianceID": "66672",
			"SID": "508661",
			"OUID": "",
			"SourceID": "55552320",
			"isUsed": true
		},
		{
			"Name": "baidubrowser",
			"AllianceID": "66672",
			"SID": "508664",
			"OUID": "",
			"SourceID": "55552323",
			"isUsed": true
		},
		{
			"Name": "miuibrowser",
			"AllianceID": "66672",
			"SID": "508669",
			"OUID": "",
			"SourceID": "55552329",
			"isUsed": true
		},
		{
			"Name": "liebaofast|lbbrowser",//liebao
			"AllianceID": "66672",
			"SID": "508663",
			"OUID": "",
			"SourceID": "55552322",
			"isUsed": true
		},
		{
			"Name": "mxbrowser|maxthon",//aoyou
			"AllianceID": "66672",
			"SID": "508667",
			"OUID": "",
			"SourceID": "55552327",
			"isUsed": true
		},
		{
			"Name": "m1|mx4",//meizu
			"AllianceID": "66672",
			"SID": "725345",
			"OUID": "",
			"SourceID": "55552379",
			"isUsed": true
		},
		{
			"Name": "honor|huawei",
			"AllianceID": "66672",
			"SID": "785834",
			"OUID": "",
			"SourceID": "55552380",
			"isUsed": true
		},
		{
			"Name": "htc",
			"AllianceID": "66672",
			"SID": "725350",
			"OUID": "",
			"SourceID": "55552381",
			"isUsed": true
		},
		{
			"Name": "2345browser",
			"AllianceID": "66672",
			"SID": "508658",
			"OUID": "",
			"SourceID": "",
			"isUsed": true
		},
		{
			"Name": "quark",//kuake
			"AllianceID": "66672",
			"SID": "1696985",
			"OUID": "",
			"SourceID": "",
			"isUsed": true
		},
		{
			"Name": "vivo",
			"AllianceID": "66672",
			"SID": "1693492",
			"OUID": "",
			"SourceID": "",
			"isUsed": true
		},
		{
			"Name": "oppo",
			"AllianceID": "66672",
			"SID": "1693487",
			"OUID": "",
			"SourceID": "",
			"isUsed": true
		},
		{
			"Name": "baidumap",
			"AllianceID": "108298",
			"SID": "552100",
			"OUID": "baidumap",
			"SourceID": "",
			"isUsed": true
		},
		{
			"Name": "nuomiapp",
			"AllianceID": "108298",
			"SID": "552100",
			"OUID": "nuomi",
			"SourceID": "",
			"isUsed": true
		},
		{
			"Name": "baidutravel",
			"AllianceID": "108298",
			"SID": "552100",
			"OUID": "baidutravel",
			"SourceID": "",
			"isUsed": true
		},
		{
			"Name": "samsung",
			"AllianceID": "66672",
			"SID": "725351",
			"OUID": "",
			"SourceID": "55552382",
			"isUsed": true
		},
	{
			"Name": "chrome|crios",
			"AllianceID": "66672",
			"SID": "1693366",
			"OUID": "",
			"SourceID": "",
			"isUsed": true
	},
	{
			"Name": "bytespider",
			"AllianceID": "1095032",
			"SID": "2820497",
			"OUID": "",
			"SourceID": "",
			"isUsed": true
		},
{
			"Name": "/version\/([\d.]+).*safari/",
			"AllianceID": "66672",
			"SID": "508670",
			"OUID": "",
			"SourceID": "",
			"isUsed": true
		}
	
	]
};